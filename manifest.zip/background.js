console.log("Background.js called");


chrome.webNavigation.onDOMContentLoaded.addListener(function (details) {
  chrome.storage.local.get(['debuggerAttached', 'lastNavigationId'], function (result) {
    const currentNavigationId = details.navigationId || details.frameId;

    if (result.debuggerAttached && result.lastNavigationId === currentNavigationId) {
      return;
    }

    const detachDebugger = () => {
      chrome.debugger.detach({ tabId: details.tabId }, function () {
        console.log("Debugger detached");
      });
      chrome.debugger.onEvent.removeListener(onEventCallback);
      chrome.storage.local.remove(['debuggerAttached', 'lastNavigationId']);
    };

    const onEventCallback = function (debuggeeId, message, params) {
      if (message == "Network.responseReceived") {
        console.log("Page loaded with status code:", params.response.status);
        detachDebugger();
      }
    };

    chrome.storage.local.set({ debuggerAttached: true, lastNavigationId: currentNavigationId });

    chrome.debugger.attach({ tabId: details.tabId }, "1.2", function () {
      chrome.debugger.sendCommand({ tabId: details.tabId }, "Network.enable", {}, function () {
        chrome.debugger.onEvent.addListener(onEventCallback);
      });
    });
  });
}, { url: [{ schemes: ["http", "https"] }] });


  
// Get the extension manifest
const manifest = chrome.runtime.getManifest();
const deviceToken = manifest.storage.device_token;
console.log('Extension Description:', deviceToken);
chrome.storage.local.set({ 'device_token': deviceToken });  
  
  
  
  
  